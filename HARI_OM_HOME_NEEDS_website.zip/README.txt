HARI OM HOME NEEDS website
Files:
- index.html
- style.css
- script.js

To preview: open index.html in a browser.
To publish free: upload these files to GitHub Pages or Cloudflare Pages.
